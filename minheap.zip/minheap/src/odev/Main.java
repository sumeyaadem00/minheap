package odev;

public class Main {


    private int pos;

    public static void main(String[] args) {

        MinHeap minHeap=new MinHeap();
        minHeap.insert(1);
        minHeap.insert(5);
        minHeap.insert(9);
        minHeap.insert(7);
        minHeap.insert(8);
        minHeap.insert(10);
        minHeap.insert(12);
        minHeap.insert(15);
        minHeap.insert(18);


        System.out.print("MinHeap");

        System.out.print(" 1, 5, 9, 7, 8, 10, 12, 15, 18 ");


        minHeap.print();


    }


}


