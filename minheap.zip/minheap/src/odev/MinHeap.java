package odev;

public class MinHeap {
    private int[] theheap;
    private int length;
    private int pos;

    public void minheap() {
        pos=1;
        length=10;
        theheap=new int[length];
    }

    public void insert(int value) {
        if (pos == length) {
        } else {
            theheap[pos++]=value;
            int child=pos - 1;
            int parent=child / 3;

            while (theheap[parent] > theheap[child] && parent > 0) {
                int tmp=theheap[parent];
                theheap[parent]=theheap[child];
                theheap[child]=tmp;

                child=parent;
                parent=child / 3;


            }
        }
    }

    public void print() {
        for (int i=1; i < pos; i++) {
            System.out.print(theheap[i] + " ");


        }
    }
}



